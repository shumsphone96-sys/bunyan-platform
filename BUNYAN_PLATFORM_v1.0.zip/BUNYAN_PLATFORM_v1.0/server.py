#!/usr/bin/env python3
import os, json, sqlite3, hashlib, hmac, secrets, time, mimetypes
from http import cookies
from urllib.parse import urlparse
from wsgiref.simple_server import make_server
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / 'data' / 'bunyan.db'
STATIC = ROOT / 'static'
SECRET = os.environ.get('BUNYAN_SECRET', 'change-this-secret-in-production')
SESSIONS = {}

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 210000)
    return salt.hex() + ':' + key.hex()

def verify_password(password, stored):
    salt_hex, key_hex = stored.split(':',1)
    calc = hash_password(password, bytes.fromhex(salt_hex)).split(':',1)[1]
    return hmac.compare_digest(calc, key_hex)

def init_db():
    DB.parent.mkdir(parents=True, exist_ok=True)
    conn=db(); c=conn.cursor()
    c.executescript('''
    PRAGMA journal_mode=WAL;
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'admin', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY, name TEXT NOT NULL, summary TEXT, status TEXT NOT NULL DEFAULT 'مخطط', budget REAL DEFAULT 0, spent REAL DEFAULT 0, progress INTEGER DEFAULT 0, start_date TEXT, end_date TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS beneficiaries(id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, phone TEXT, service TEXT, status TEXT DEFAULT 'نشط', notes TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS volunteers(id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, phone TEXT, skill TEXT, hours REAL DEFAULT 0, status TEXT DEFAULT 'نشط', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS donations(id INTEGER PRIMARY KEY, donor TEXT NOT NULL, amount REAL NOT NULL, currency TEXT DEFAULT 'SDG', donation_type TEXT DEFAULT 'غير مقيد', payment_method TEXT, project_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(project_id) REFERENCES projects(id));
    CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT NOT NULL);
    ''')
    if not c.execute('SELECT 1 FROM users LIMIT 1').fetchone():
        pwd=os.environ.get('BUNYAN_ADMIN_PASSWORD','ChangeMe123!')
        c.execute('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)',('admin',hash_password(pwd),'admin'))
    if not c.execute('SELECT 1 FROM projects LIMIT 1').fetchone():
        c.execute('INSERT INTO projects(name,summary,status,budget,spent,progress) VALUES(?,?,?,?,?,?)',('مشروع الأساس','تأسيس الأنظمة والهوية والحوكمة','قيد التنفيذ',1500000,250000,35))
    conn.commit(); conn.close()

def body_json(environ):
    try:
        n=int(environ.get('CONTENT_LENGTH') or 0)
        return json.loads(environ['wsgi.input'].read(n) or b'{}')
    except Exception:
        return {}

def response(start, data, status='200 OK', headers=None):
    raw = data if isinstance(data,(bytes,bytearray)) else json.dumps(data,ensure_ascii=False).encode()
    hs=[('Content-Type','application/json; charset=utf-8'),('Content-Length',str(len(raw))),('X-Content-Type-Options','nosniff'),('X-Frame-Options','DENY'),('Referrer-Policy','strict-origin-when-cross-origin')]
    if headers: hs += headers
    start(status,hs); return [raw]

def static_response(start, path):
    fp=(STATIC/path.lstrip('/')).resolve()
    if not str(fp).startswith(str(STATIC.resolve())) or not fp.exists() or not fp.is_file():
        return response(start, {'error':'Not found'}, '404 Not Found')
    raw=fp.read_bytes(); typ=mimetypes.guess_type(fp.name)[0] or 'application/octet-stream'
    start('200 OK',[('Content-Type',typ),('Content-Length',str(len(raw))),('Cache-Control','no-cache')]); return [raw]

def get_session(environ):
    jar=cookies.SimpleCookie(environ.get('HTTP_COOKIE','')); sid=jar.get('bunyan_session')
    if not sid: return None
    rec=SESSIONS.get(sid.value)
    if not rec or rec['expires'] < time.time(): return None
    return rec

def require_auth(environ,start):
    s=get_session(environ)
    if not s: return None, response(start, {'error':'غير مصرح'}, '401 Unauthorized')
    return s, None

def table_rows(table):
    conn=db(); rows=[dict(r) for r in conn.execute(f'SELECT * FROM {table} ORDER BY id DESC').fetchall()]; conn.close(); return rows

def app(environ,start):
    path=urlparse(environ.get('PATH_INFO','/')).path; method=environ.get('REQUEST_METHOD','GET').upper()
    if path=='/': return static_response(start,'index.html')
    if path.startswith('/static/'): return static_response(start,path[len('/static/'):])
    if path=='/api/health': return response(start, {'status':'ok','service':'BUNYAN Platform'})
    if path=='/api/public/summary':
        conn=db()
        out={
          'projects':conn.execute('SELECT COUNT(*) FROM projects').fetchone()[0],
          'beneficiaries':conn.execute('SELECT COUNT(*) FROM beneficiaries').fetchone()[0],
          'volunteers':conn.execute('SELECT COUNT(*) FROM volunteers').fetchone()[0],
          'donations':conn.execute('SELECT COALESCE(SUM(amount),0) FROM donations').fetchone()[0],
          'featured':[dict(r) for r in conn.execute('SELECT id,name,summary,status,budget,spent,progress FROM projects ORDER BY id DESC LIMIT 6')]
        }; conn.close(); return response(start,out)
    if path=='/api/login' and method=='POST':
        x=body_json(environ); conn=db(); u=conn.execute('SELECT * FROM users WHERE username=?',(x.get('username',''),)).fetchone(); conn.close()
        if not u or not verify_password(x.get('password',''),u['password_hash']): return response(start,{'error':'بيانات الدخول غير صحيحة'},'401 Unauthorized')
        sid=secrets.token_urlsafe(32); SESSIONS[sid]={'user':u['username'],'role':u['role'],'expires':time.time()+28800}
        return response(start,{'ok':True,'user':u['username']},headers=[('Set-Cookie',f'bunyan_session={sid}; Path=/; HttpOnly; SameSite=Strict; Max-Age=28800')])
    if path=='/api/logout' and method=='POST':
        jar=cookies.SimpleCookie(environ.get('HTTP_COOKIE','')); sid=jar.get('bunyan_session')
        if sid: SESSIONS.pop(sid.value,None)
        return response(start,{'ok':True},headers=[('Set-Cookie','bunyan_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0')])
    if path=='/api/me':
        s=get_session(environ); return response(start, {'authenticated':bool(s),'user':s['user'] if s else None,'role':s['role'] if s else None})
    if path=='/api/dashboard':
        s,err=require_auth(environ,start)
        if err:return err
        conn=db(); out={
          'projects':conn.execute('SELECT COUNT(*) FROM projects').fetchone()[0],
          'beneficiaries':conn.execute('SELECT COUNT(*) FROM beneficiaries').fetchone()[0],
          'volunteers':conn.execute('SELECT COUNT(*) FROM volunteers').fetchone()[0],
          'donations':conn.execute('SELECT COALESCE(SUM(amount),0) FROM donations').fetchone()[0],
          'budget':conn.execute('SELECT COALESCE(SUM(budget),0) FROM projects').fetchone()[0],
          'spent':conn.execute('SELECT COALESCE(SUM(spent),0) FROM projects').fetchone()[0]
        }; conn.close(); return response(start,out)
    tables={'projects','beneficiaries','volunteers','donations'}
    parts=[p for p in path.split('/') if p]
    if len(parts)>=2 and parts[0]=='api' and parts[1] in tables:
        s,err=require_auth(environ,start)
        if err:return err
        table=parts[1]
        if len(parts)==2 and method=='GET': return response(start,table_rows(table))
        payload=body_json(environ)
        allowed={
          'projects':['name','summary','status','budget','spent','progress','start_date','end_date'],
          'beneficiaries':['full_name','phone','service','status','notes'],
          'volunteers':['full_name','phone','skill','hours','status'],
          'donations':['donor','amount','currency','donation_type','payment_method','project_id']
        }[table]
        data={k:payload.get(k) for k in allowed if k in payload}
        conn=db()
        try:
            if len(parts)==2 and method=='POST':
                if not data: raise ValueError('لا توجد بيانات')
                cols=','.join(data); qs=','.join('?' for _ in data)
                cur=conn.execute(f'INSERT INTO {table}({cols}) VALUES({qs})',tuple(data.values())); conn.commit(); rid=cur.lastrowid
                row=dict(conn.execute(f'SELECT * FROM {table} WHERE id=?',(rid,)).fetchone()); return response(start,row,'201 Created')
            if len(parts)==3 and parts[2].isdigit():
                rid=int(parts[2])
                if method in ('PUT','PATCH'):
                    if not data: raise ValueError('لا توجد بيانات')
                    sets=','.join(f'{k}=?' for k in data); conn.execute(f'UPDATE {table} SET {sets} WHERE id=?',tuple(data.values())+(rid,)); conn.commit()
                    row=conn.execute(f'SELECT * FROM {table} WHERE id=?',(rid,)).fetchone(); return response(start,dict(row) if row else {'error':'غير موجود'},'200 OK' if row else '404 Not Found')
                if method=='DELETE': conn.execute(f'DELETE FROM {table} WHERE id=?',(rid,)); conn.commit(); return response(start,{'ok':True})
        except Exception as e:
            return response(start,{'error':str(e)},'400 Bad Request')
        finally: conn.close()
    if path=='/api/backup' and method=='GET':
        s,err=require_auth(environ,start)
        if err:return err
        payload={t:table_rows(t) for t in ['projects','beneficiaries','volunteers','donations']}
        return response(start,payload,headers=[('Content-Disposition','attachment; filename=bunyan-backup.json')])
    return response(start, {'error':'Not found'}, '404 Not Found')

if __name__=='__main__':
    init_db(); port=int(os.environ.get('PORT','8080'))
    print(f'BUNYAN running on http://0.0.0.0:{port}')
    make_server('0.0.0.0',port,app).serve_forever()
